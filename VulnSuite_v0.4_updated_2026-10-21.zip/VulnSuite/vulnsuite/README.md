# 🛡️ VulnSuite

**A BFSI-tuned, multi-tool, risk-prioritized cybersecurity vulnerability analysis platform.**

> Passive-only. Own-assets. Multi-tenant. Air-gap ready. RBI CSF & CERT-In aligned.

---

## 📌 Executive Summary

VulnSuite unifies **eleven industry-standard security scanners** behind a single **risk engine** that prioritizes findings using `CVSS × EPSS × asset criticality × exposure` — transforming tens of thousands of raw CVEs into a **focused P0–P4 queue** a CISO can actually action.

Built for Indian BFSI from day one: **RBI Cyber Security Framework** controls and **CERT-In 6-hour incident reporting** are embedded in every finding, not bolted on later.

---

## 🧭 Architecture

<p align="center">
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 360" width="800">
  <style>
    .box{fill:#0a2540;stroke:#0a2540;}
    .box2{fill:#1a4d7a;stroke:#1a4d7a;}
    .box3{fill:#2e86ab;stroke:#2e86ab;}
    .txt{fill:#fff;font-family:Helvetica,Arial;font-size:13px;font-weight:bold;text-anchor:middle;}
    .small{fill:#fff;font-family:Helvetica,Arial;font-size:10px;text-anchor:middle;}
    .arrow{stroke:#555;stroke-width:2;fill:none;marker-end:url(#a);}
  </style>
  <defs><marker id="a" markerWidth="10" markerHeight="10" refX="9" refY="3" orient="auto"><path d="M0,0 L0,6 L9,3 z" fill="#555"/></marker></defs>

  <rect class="box" x="20" y="20" width="150" height="60" rx="6"/>
  <text class="txt" x="95" y="45">Collectors (11)</text>
  <text class="small" x="95" y="62">SCA · SAST · Secrets</text>
  <text class="small" x="95" y="75">Net · Cloud · Container</text>

  <rect class="box2" x="220" y="20" width="150" height="60" rx="6"/>
  <text class="txt" x="295" y="45">Orchestrator</text>
  <text class="small" x="295" y="62">parallel · dedup</text>
  <text class="small" x="295" y="75">risk-score · persist</text>

  <rect class="box3" x="420" y="20" width="150" height="60" rx="6"/>
  <text class="txt" x="495" y="45">Risk Engine</text>
  <text class="small" x="495" y="62">CVSS × EPSS × crit</text>
  <text class="small" x="495" y="75">× exposure → P0-P4</text>

  <rect class="box" x="620" y="20" width="150" height="60" rx="6"/>
  <text class="txt" x="695" y="45">PostgreSQL</text>
  <text class="small" x="695" y="62">RLS · multi-tenant</text>
  <text class="small" x="695" y="75">+ DuckDB archive</text>

  <line class="arrow" x1="170" y1="50" x2="220" y2="50"/>
  <line class="arrow" x1="370" y1="50" x2="420" y2="50"/>
  <line class="arrow" x1="570" y1="50" x2="620" y2="50"/>

  <rect class="box2" x="20" y="140" width="150" height="60" rx="6"/>
  <text class="txt" x="95" y="165">FastAPI</text>
  <text class="small" x="95" y="182">OIDC · RBAC · REST</text>

  <rect class="box2" x="220" y="140" width="150" height="60" rx="6"/>
  <text class="txt" x="295" y="165">Celery Workers</text>
  <text class="small" x="295" y="182">scan · discover · report</text>

  <rect class="box2" x="420" y="140" width="150" height="60" rx="6"/>
  <text class="txt" x="495" y="165">Streamlit Dashboard</text>
  <text class="small" x="495" y="182">CISO view · trends</text>

  <rect class="box2" x="620" y="140" width="150" height="60" rx="6"/>
  <text class="txt" x="695" y="165">PDF + CERT-In</text>
  <text class="small" x="695" y="182">board-ready · audit hash</text>

  <rect class="box3" x="120" y="260" width="560" height="60" rx="6"/>
  <text class="txt" x="400" y="285">Compliance Layer</text>
  <text class="small" x="400" y="302">RBI CSF Annex-I · CERT-In 6h · ISO 27001 · NIST · CIS Azure · CIS Docker</text>
</svg>
</p>

---

## 🎯 The Risk Formula

<p align="center">
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 720 130" width="720">
  <style>
    .f{font-family:"Courier New",monospace;font-size:20px;fill:#0a2540;font-weight:bold;}
    .l{font-family:Helvetica,Arial;font-size:11px;fill:#555;}
  </style>
  <text class="f" x="360" y="50" text-anchor="middle">risk_score = CVSS × EPSS × (criticality/5) × exposure</text>
  <text class="l" x="120" y="85" text-anchor="middle">0–10</text>
  <text class="l" x="120" y="100" text-anchor="middle">technical</text>
  <text class="l" x="260" y="85" text-anchor="middle">0–1</text>
  <text class="l" x="260" y="100" text-anchor="middle">exploitability</text>
  <text class="l" x="440" y="85" text-anchor="middle">0.2–1.0</text>
  <text class="l" x="440" y="100" text-anchor="middle">business impact</text>
  <text class="l" x="620" y="85" text-anchor="middle">0.3 / 0.6 / 1.0</text>
  <text class="l" x="620" y="100" text-anchor="middle">blast radius</text>
</svg>
</p>

**Buckets:** P0 ≥ 7.0 (CERT-In clock) · P1 ≥ 4.5 · P2 ≥ 2.0 · P3 ≥ 0.5 · P4 otherwise.

---

## 🔬 Scanner Coverage

| Module | Tools | Coverage |
|---|---|---|
| **SCA** | Trivy · pip-audit · OSV-Scanner | NVD + PyPA + OSV.dev, triple-corroborated |
| **Secrets** | gitleaks · TruffleHog | Regex breadth + live credential verification |
| **SAST** | Semgrep · Bandit | Multi-language + Python deep crypto checks |
| **Network** | nmap (passive) · testssl.sh | Service/version + TLS hygiene (RBI Annex-I 6.2) |
| **Cloud** | Prowler Azure | CIS Azure 2.0 + ISO 27001 + NIST 800-53 |
| **Container** | Trivy image · Dockle | Image CVEs + CIS Docker Benchmark hardening |
| **Discovery** | Azure Resource Graph | Auto-inventory with tag-based criticality inference |

---

## 🏛️ Compliance Mapping

Every finding carries a **regulatory citation** in its evidence block:

- **RBI Cyber Security Framework** — Annex-I controls 6.2 (crypto/TLS), 6.3 (patching), 6.4 (hardening), 6.5 (certificates), 6.13 (cloud), 6.14 (SDLC), 6.15 (secrets), 6.16 (database)
- **CERT-In Directions 28 Apr 2022** — auto-generated 6-hour incident report for every P0 finding
- **ISO 27001:2013** — Annex A control mapping via Prowler
- **CIS Benchmarks** — Azure 2.0, Docker
- **NIST 800-53 Rev 5** — via Prowler compliance packs
- **OWASP Top 10** — via Semgrep rule packs

---

## 🏗️ Repository Layout

```
vulnsuite/
├── core/                 # schema, db, risk engine, orchestrator, dedup, EPSS, config
├── collectors/
│   ├── sca/              # trivy, pip_audit, osv_scanner
│   ├── secrets/          # gitleaks, trufflehog
│   ├── sast/             # semgrep, bandit
│   ├── network/          # nmap_passive, testssl
│   ├── cloud/            # prowler_azure
│   ├── container/        # dockle
│   └── discovery/        # azure_inventory
├── api/                  # FastAPI app + OIDC/RBAC
├── workers/              # Celery app + tasks
├── reporting/            # PDF generator (Jinja2 + WeasyPrint)
├── compliance/           # rbi_mapping, certin_export
├── dashboard/            # Streamlit CISO view
├── deploy/               # docker-compose.yml (+ Helm chart TBD)
├── pyproject.toml
└── README.md
```

---

## 🛡️ Security & Privacy by Design

1. **Passive-only mode** — no exploitation, no auth probing, no aggressive timing. Enforced in code (nmap collector refuses `T4`/`T5` at construction time).
2. **Tenant-bound API access and PostgreSQL Row-Level Security** — the API verifies the signed tenant claim and binds it to every database transaction; forced row policies restrict reads and writes to that tenant. This depends on trusted tenant binding and restricted application credentials. It does not isolate tenants from someone able to execute arbitrary SQL with those credentials or alter the table policies.
3. **Secrets never stored in findings DB** — TruffleHog raw values are explicitly redacted; gitleaks uses `--redact`.
4. **Air-gap support on every network-dependent component** — Trivy offline DB, OSV-Scanner local DB, Semgrep offline rules, EPSS offline CSV.
5. **No telemetry egress** — Semgrep `--metrics off`, Bandit offline, Trivy `--skip-db-update` option.
6. **Audit-stamped PDFs** — every generated report carries an SHA-256 content hash in the footer.
7. **Read-only cloud credentials** — Prowler Azure uses Reader + Security Reader roles only.
8. **OIDC + RBAC** — four roles (admin, analyst, viewer, auditor) with least-privilege route guards.

---

## 🚀 Quick Start

Run these commands from the directory containing this README and `pyproject.toml`. For an existing PostgreSQL volume, complete the role and ownership migration in [the deployment guide](deploy/AUTH_DEPLOYMENT.md) before starting the updated application.

```bash
# Create a private configuration file outside the checkout.
mkdir -p "$HOME/.config/vulnsuite"
install -m 600 deploy/auth.env.example "$HOME/.config/vulnsuite/compose.env"

# Edit that file: set independent DB_PASSWORD and POSTGRES_BOOTSTRAP_PASSWORD,
# plus the trusted OIDC issuer, audience, public JWKS URL and claim mappings.
# Generate each database password independently, for example: openssl rand -hex 32

# Validate without printing resolved credentials, then build and start.
docker compose --env-file "$HOME/.config/vulnsuite/compose.env" \
  -f deploy/docker-compose.yml config --quiet
docker compose --env-file "$HOME/.config/vulnsuite/compose.env" \
  -f deploy/docker-compose.yml up -d --build

# API documentation: http://localhost:8000/docs
# Protected routes require an IdP access token and matching X-Tenant-Id.
```

- Fresh database volumes create a separate `NOSUPERUSER NOBYPASSRLS` application role. Bootstrap administrator credentials stay in the database container. Missing credentials or OIDC configuration stop Compose startup.
- The authenticated SOC console is supplied by the separately deployed protection service at `/console`; follow [the operations deployment guide](../deploy/protection/OPERATIONS.md). This Compose file starts the assessment API, database, workers and scheduler.
- The old Streamlit dashboard is disabled by default. Its explicit `legacy-dashboard` profile binds only to localhost and retains manual tenant selection; it is unsuitable as a public multi-tenant interface.
- Configure HTTPS ingress and verify a staging identity-provider/database deployment before production use. See [database migration, credential requirements and staging checks](deploy/AUTH_DEPLOYMENT.md).

---

## 📊 Observability

- **Structured JSON logs** via structlog — ship to Splunk/Sentinel/ELK
- **Per-tool scan error capture** — failures aggregate into `RunReport.errors`, never crash the pipeline
- **MTTR & aging metrics** on the Streamlit dashboard
- **DuckDB cold-store archive** for historical trend queries without burdening PostgreSQL

---

## 🗺️ Roadmap

| Phase | Status | Scope |
|---|---|---|
| 1 | ✅ Done | Schema, DB, risk engine, SCA + Secrets + SAST collectors, orchestrator, dedup, EPSS |
| 2 | ✅ Done | Network collectors, PDF reporting |
| 3 | ✅ Done | Cloud + container + discovery collectors, compliance layer |
| 4 | ✅ Done | API, workers, dashboard, docker-compose deployment |
| 5 | 🔜 | Helm chart, Alembic migrations, AWS Prowler, SIEM connectors (Splunk/Sentinel), automated remediation playbooks |

---

## 📜 License

Proprietary — internal BFSI deployment only. Contact the security team for external-use licensing.

**Classification:** CONFIDENTIAL — INTERNAL USE ONLY

## Server intrusion monitoring and response

An initial Linux server-protection module is available alongside vulnerability scanning. It provides SSH/API access alerts, file-integrity and suspicious-process monitoring, optional ClamAV/hash detection, cross-host lateral-movement signals, ModSecurity/OWASP CRS integration, sensor health, durable audit records, and operator-requested temporary IP blocking. See [deployment, supported coverage and limitations](protection/README.md). It is a separately authenticated, single-organisation service and is not a complete EDR or WAF.

### Operational enhancements

Verified JWT/SSO access-token validation, role checks, a unified operations console, central agent enrollment, Windows/Linux audit telemetry, incident workflows, notification delivery and reviewed containment are implemented. See [the operations guide](protection/OPERATIONS.md) for configuration, tests and deployment boundaries.

Release 0.4 adds Windows-native quarantine/restoration and temporary firewall
isolation/release, using the same separate-actor approval workflow as Linux.
Windows response requires explicit local enablement, native ACL/helper setup and
staging validation; see the [Windows setup and recovery guide](../deploy/protection/windows/README.md).

## Deployment on 10.91.16.86 (20 October 2026)

The checkout was fast-forwarded from `dd5b320` to upstream `2c8c274` over HTTPS.
All tracked upstream files are present. Deployment changes are included in the
21 October 2026 source package and repository update.

- Continuous monitoring: `http://10.91.16.86/VulnSuite/`; `/infosec` redirects here.
- Vulnerability findings: `http://10.91.16.86/VulnSuite/findings/`.
- Authenticated operations: `http://10.91.16.86/VulnSuite/operations/console`.
  On this server, read `runtime/protection/operator-token` and paste it into the
  console's access-token field. The file is mode 0600; do not commit or share it.
- The assessment API is loopback-only on port 8137. Its RS256 verifier uses an
  offline public JWKS, not enterprise SSO. The private signing key is in
  `runtime/local-signing.pem` (0600). The protection bridge uses a tenant-scoped
  viewer JWT lasting eight hours and renewed every four hours.

### Actual coverage

The monitoring collector runs every minute and the browser polls every 15 seconds.
Sources are Defender health and local detection history, systemd service health,
SSH journal aggregates, bounded Linux audit record counts, bounded Nginx request
summaries, Docker inventory, TCP listeners, the findings database, protection
agent telemetry, and scanner installation status. Source failures are explicit;
a snapshot older than 180 seconds is stale and fails the health endpoint.

The protection agent collects every ten seconds. Its configured sensors cover
SSH failure/success correlation, HTTP 401/403 bursts on the IP's port-80 virtual
host, selected system configuration file integrity, and suspicious process
patterns. Delivery is durable and sensor health is visible. Its initial baseline
is the deployment state, not a forensic certification of a clean host.

Dashboard alerts are enabled. Email, Teams, webhooks, cloud SIEM feeds, automatic
blocking, isolation, and quarantine are **disabled**. Azure Monitor and Site24x7
agents exist but their cloud feeds are not configured. Audit records are counted;
no additional kernel execution audit rules were loaded. Defender provides the
existing endpoint malware protection; VulnSuite's separate malware scanner is not
configured. There is no claim of complete intrusion detection.

Hourly Bandit scans cover **VulnSuite's own source only**. Findings are persisted
in the dedicated database. Other tools are installed but require chosen targets,
cloud/cluster credentials, templates or vulnerability database downloads before
those scans can provide coverage. No network-wide or active attack scans were run.
The repository's old Trivy and ZAP release URLs returned 404; this deployment uses
Trivy 0.76.0 and ZAP 2.17.0 with verified release asset hashes. ZAP has a private
JRE17. Nmap 7.95 was built in `.tools/nmap-local`; system package installation
failed before installation, so the host package stack was not used. Other binary
versions follow `deploy/install-scanner-binaries.py`; Python tool environments are
isolated in `.venv`, `.tools/prowler`, and `.tools/checkov`.

### Services and storage

Systemd services: `vulnsuite-monitor`, `vulnsuite-api`, `vulnsuite-worker`,
`vulnsuite-beat`, `vulnsuite-findings`, `vulnsuite-protection`, `vulnsuite-agent`.
Timers: `vulnsuite-collect`, `vulnsuite-local-scan`, `vulnsuite-read-token`.
All long-running services and timers are enabled at boot. The cloud discovery
schedule stays empty until Azure credentials are configured.

Docker Compose project `vulnsuite`, in `deploy/server-compose.yml`, owns separate
PostgreSQL and Redis volumes. Their ports are loopback-only (15436 and 16386).
PostgreSQL application credentials use NOSUPERUSER/NOBYPASSRLS with FORCE RLS.
Redis requires a random password. Secrets are in `../runtime/server.env` (0600).
The original shared databases and application ports are not reused.

The dashboard serves sanitized snapshots from `/var/lib/vulnsuite-monitor` using
root-owned code in `/opt/vulnsuite-monitor`. Its collector is a bounded read-only
root process; its HTTP server has a dynamic unprivileged identity. The protection
agent has read/ptrace capabilities for host sensor visibility, no network-admin
capability, and a read-only filesystem except its private state directory.

Snapshot history is limited to 24 hours and monitoring alert history to seven
days. Protection data uses the repository's seven-day retention policy. Findings
persist in PostgreSQL. Nginx denial telemetry contains only IP and status, with a
separate seven-rotation configuration at `/etc/logrotate.d/vulnsuite-security`.
The server already has a failing logrotate service; the dashboard surfaces this.
Operators should repair that existing host issue and monitor disk usage.

Nginx changes are limited to a route include and an additional filtered denial
log in the IP's HTTP server, plus a new log format. Existing routes remain in
place. Route definitions are in `/etc/nginx/snippets/vulnsuite.conf`.

### Checks and operations

Validation: 344 automated tests passed, six skipped; skipped integration/native
checks are not claimed as verified. Browser checks loaded monitoring, findings,
and authenticated operations with no JavaScript errors. The assessment bridge
returned real findings. Invalid and cross-tenant credentials were rejected, and
a separate tenant could not read the local tenant's rows. Nginx configuration
validation and HTTP health checks passed. The monitoring service was restarted
and verified. Scanner installation does not imply every collector was exercised
against a live target.

Useful commands, run from the repository root:

```bash
curl -fsS http://10.91.16.86/VulnSuite/health
sudo systemctl status vulnsuite-monitor vulnsuite-agent vulnsuite-protection
sudo systemctl list-timers 'vulnsuite-*'
sudo journalctl -u vulnsuite-agent -u vulnsuite-collect --since '1 hour ago'
sudo systemctl start vulnsuite-local-scan
cat runtime/protection/operator-token
sudo docker compose --env-file runtime/server.env -p vulnsuite -f vulnsuite/deploy/server-compose.yml ps
```

Before changing configuration, preserve `runtime/`, PostgreSQL/Redis volumes,
and `/var/lib/vulnsuite-monitor`. To roll back routing, remove only the VulnSuite
include and extra denial access_log from the IP server, run `nginx -t`, then reload.
Disable only `vulnsuite-*` services/timers and stop the `vulnsuite` Compose project
without `-v` to retain data. Do not restore a whole shared Nginx config over later
unrelated edits. A pre-deployment backup is available as
`/etc/nginx/conf.d/nbfc-toolbox.conf.pre-vulnsuite`.
